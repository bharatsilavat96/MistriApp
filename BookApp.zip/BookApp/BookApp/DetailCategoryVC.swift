//
//  DetailCategoryVC.swift
//  BookApp
//
//  Created by Bharat Silavat on 08/02/23.
//

import UIKit

class DetailCategoryVC: UIViewController {
   

    var bookListArray: [Book] = []
    @IBOutlet weak var bookListCollection: UICollectionView!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        bookListCollection.dataSource = self
    }
    
}

extension DetailCategoryVC: UICollectionViewDataSource {
   
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return bookListArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BookCollectionViewCell", for: indexPath) as! BookCollectionViewCell
//        cell.bookImgView.image = 
        cell.bookName.text = bookListArray[indexPath.row].kind
        return cell
    }
 
}
extension DetailCategoryVC: UICollectionViewDelegateFlowLayout{
    
}
