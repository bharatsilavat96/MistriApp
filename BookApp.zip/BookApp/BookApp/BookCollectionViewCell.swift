//
//  BookCollectionViewCell.swift
//  BookApp
//
//  Created by Bharat Silavat on 09/02/23.
//

import UIKit

class BookCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var bookImgView: UIImageView!
    @IBOutlet weak var bookName: UILabel!
    
    
    
    
}
