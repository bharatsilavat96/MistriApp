//
//  BookViewController.swift
//  BookApp
//
//  Created by Bharat Silavat on 08/02/23.
//

import UIKit

class BookViewController: UIViewController {

    

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

   

}
